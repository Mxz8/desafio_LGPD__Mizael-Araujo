

//carousel

//Array storage class
let carouselArr = [];



//class Carousel
class Carousel {
    
    constructor(image,title,url){
        this.image = image;
        this.title = title;
        this.url = url;
    }
        

    
      
    static Start(arr){
        if(arr){

            if(arr.length > 0){
                Carousel._sequence = 0;
                Carousel._size = arr.length;
                Carousel._items = arr
                Carousel._carouselDom() 
                Carousel._mostrarCarousel()
                Carousel.Next(); //start
                Carousel._interval = setInterval(function(){ Carousel.Next(); },2000);
            }
            
        } else {
            throw "Method Start need a Array Variable.";
        }
    }
    static _carouselDom(){
        const carousel = document.getElementById("carousel")
        const titulo = document.getElementById("carousel-title")

        const carouselLink = document.createElement('a');
        carouselLink.id = 'carousel-link';
        carouselLink.href = '#';

        const carouselImage = document.createElement('img');
        carouselImage.id = 'carousel-image';
        carouselImage.src = '';
        carouselImage.alt = '';
        
        const prevButton = document.createElement('button');
        prevButton.id = 'carousel-prev';
        prevButton.textContent = 'Prev';
        
        const nextButton = document.createElement('button');
        nextButton.id = 'carousel-next';
        nextButton.textContent = 'Next';           


        const carouselText = document.createElement('h2');
        carouselText.id = 'carousel-text'
        
         // Adiciona ao carousel principal
        carouselLink.appendChild(carouselImage);
        carousel.appendChild(carouselLink);        
        carousel.appendChild(prevButton);
        carousel.appendChild(nextButton);
        titulo.appendChild(carouselText);

        document.getElementById('carousel-prev').addEventListener('click', Carousel.Prev);
        document.getElementById('carousel-next').addEventListener('click', Carousel.Next);
    }
              
    static _mostrarCarousel(){
        const corrente = Carousel._items[Carousel._sequence];
        const carouselImages = document.getElementById("carousel-image");
        const tituloText = document.getElementById("carousel-text");
        const carouselLink = document.getElementById("carousel-link");

        carouselImages.src = corrente.image;
        carouselImages.alt = corrente.title;
        tituloText.textContent = corrente.title;
        carouselLink.href = corrente.link;
     } 

    static Next(){
        
        Carousel._sequence = (Carousel._sequence + 1) % Carousel._size;
        Carousel._mostrarCarousel();
        Carousel._resetInterval();     
       
    }
    static Prev(){
        
        Carousel._sequence = (Carousel._sequence + 1) % Carousel._size;
        Carousel._mostrarCarousel();
        Carousel._resetInterval();     
       
    }

    static _resetInterval() {
        clearInterval(Carousel._interval);
        Carousel._interval = setInterval(Carousel.Next, 2000);
    }


};
